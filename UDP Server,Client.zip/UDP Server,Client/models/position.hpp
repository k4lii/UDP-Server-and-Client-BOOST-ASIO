
typedef struct {
    float x;
    float y;
} position_t;
