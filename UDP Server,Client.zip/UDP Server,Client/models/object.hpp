/*
** EPITECH PROJECT, 2020
** Visual Studio Live Share (Workspace)
** File description:
** object
*/

#pragma once

#include <string>

#include "position.hpp"

typedef struct {
    position_t pos;
    std::string sprite_id;
} object_t;
