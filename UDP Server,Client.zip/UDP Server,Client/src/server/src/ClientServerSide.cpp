/*
** EPITECH PROJECT, 2020
** B-CPP-501-LYN-5-1-rtype-lorris.hamdaoui [WSL: Ubuntu-20.04]
** File description:
** ClientServerSide
*/

#include "ClientServerSide.hpp"

ClientServerSide::ClientServerSide()
{
}

ClientServerSide::~ClientServerSide()
{
}
